# Connected Linkage and Alignment Redefinition of COGs (CLARC)

🚧🚧 Description under construction, come back later 🚧🚧

The package should work though 👀 For basic instructions on how to install and run CLARC, see [this repository](https://github.com/IndraGonz/nfds-tutorial)
